package com.example.projectthree;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;
    ListView listView;
    EditText itemNameEditText, itemQtyEditText;
    Button addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        listView = findViewById(R.id.itemsListView);
        itemNameEditText = findViewById(R.id.itemNameEditText);
        itemQtyEditText = findViewById(R.id.itemQtyEditText);
        addButton = findViewById(R.id.addButton);

        addButton.setOnClickListener(v -> addItem());

        loadItems();
    }

    private void addItem() {
        String name = itemNameEditText.getText().toString();
        int quantity = Integer.parseInt(itemQtyEditText.getText().toString());

        dbHelper.addItem(name, quantity);
        loadItems();
    }

    private void loadItems() {
        Cursor cursor = dbHelper.getAllItems();
        ArrayList<String> items = new ArrayList<>();
        while (cursor.moveToNext()) {
            String name = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COL_ITEM_NAME));
            int qty = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COL_ITEM_QUANTITY));
            items.add(name + " - " + qty);
        }
        cursor.close();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, items);
        listView.setAdapter(adapter);
    }
}